# dsh-team-conductor

A TypeScript Cordis plugin for a durable, externally reviewed DSH conductor team. Targets Node **24+**, DSH **0.1.5-alpha.2**, and Gitea **1.26**.

- **Source/Release Repository**: `cchifor/dsh-team-conductor`

## Workflow

```text
Astra plan -> Qwen reviewer plan review -> Qwen worker implementation
  -> Qwen reviewer implementation review -> host-gated publication
  -> wait for reviewer-claude + reviewer-codex
  -> worker remediation -> internal review -> same PR update -> wait
  -> external merge observed -> MERGED
```

Rejected plans return to planning. Rejected implementations return to the worker. Reviews are bound to plan hashes or Git tree IDs; test evidence is produced by the host, not trusted from model prose. Two distinct current-head external approvals plus configured checks make a PR ready; **only an external actor merges it**. The adapter exposes no merge method.

## Build and test

```sh
npm ci --ignore-scripts
npm test
```

The committed `.npmrc` uses `legacy-peer-deps` because the DSH host supplies its plugin peer graph; this prevents npm from mixing newer prerelease peers into the pinned SDK fixture. Do not use this development fixture as a standalone DSH runtime.

Tests use Node's built-in runner, mocked DSH/Gitea transports, real SQLite, local temporary Git repositories, and signed local webhook requests. They do **not** call paid models, configure production reviewers, push to Gitea, or prove that your container runtime/model endpoints work.

## Layout

- `plugin.ts`: Cordis service `ctx.teamConductor`, stage-root lifecycle, host polling, fixed repository scope.
- `src/engine.ts`, `domain.ts`: state machine and strict stage results.
- `src/store.ts`: SQLite WAL/FULL persistence, revision CAS, attempts, leases, deduplicated inbox, audit trail.
- `src/dsh.ts`: native DSH subagent dispatch with fixed model routes and role tools.
- `src/files.ts`, `tools.ts`: dedicated checkout-only source tools; no host filesystem, Git metadata, links, shell, or credentials.
- `src/tool-authorization.ts`: global SDK `tools.guard` execution allowlist; role-based team tool authorization (not local filter/maxDepth).
- `src/workspace.ts`: exact-tree validation/publication and ambiguous-push reconciliation.
- `src/validation.ts`: digest-pinned container validation against a disposable source copy, without network/secrets/Git metadata.
- `src/gitea.ts`, `forge.ts`: authenticated API, pagination, canonical reviews/checks, idempotent PR binding.
- `src/ingress.ts`: bounded HMAC-verified Gitea ingress; SQLite commit before HTTP 202.
- `config/team.example.json`: **disabled** deployment configuration.

## Model routes

| Role | Provider/Model | Route |
|---|---|---|
| Conductor | `openai-codex/gpt-6-astra` | Existing DSH `openai-codex` provider |
| Worker | `litellm/qwen3.8-27b-vllm-cloud` | Existing DSH `litellm` provider |
| Internal reviewer | `litellm/qwen3.8-flash-next-cloud` | Existing DSH `litellm` provider |

These routes are declared in ailab's DSH settings seed. All inference uses existing authorized DSH provider bindings; direct cloud-IP access is intentionally excluded by the DSH network policy. Catalog presence does not prove tool/abort canary acceptance. Credentials remain DSH-managed, never literals. Set verified context/output limits; no fallback is implemented. All model calls use DSH-native dispatch; there is no external CLI or raw Astra API path (`dsh_only` behavior).

## Install as a plugin

Build this package and install it into the intended DSH profile with the DSH CLI:

```sh
./ops/release/build-tarball.sh
dsh plugin --profile <profile> add ./dist/release/dsh-team-conductor-0.1.0.tgz
```

**Prerequisites**: pnpm must be available on PATH for the DSH plugin system to resolve dependencies. Verify with `which pnpm` before installation.

The package declares an inert-by-default DSH profile bundle. Set `DSH_TEAM_CONDUCTOR_CONFIG` to an absolute trusted configuration path (or use an operator-managed profile override) to mount it in the host composition, where `agents`, `subagents`, `tools`, `credentials`, and `agentPresets` exist. See [RELEASE.md](RELEASE.md) for installation tests, activation, persistent storage and rollback. Preserve the existing Web service; no new GUI server is required.

Copy `config/team.example.json` into trusted deployment configuration, verify provider bindings and replace the image placeholder, and point the profile bundle's `configPath` at it. Direct host integrations may instead pass the object to the exported service. Create the database parent directory with owner-only permissions first. Keep the database and deployment settings **outside** `workspaceRoot`. Use a local durable filesystem with SQLite locking support. The plugin is single-coordinator/single-host; do not share it between active replicas.

The configured `agentPreset` must load a working agent loop and spawn subagent backend. The plugin provides separate `team_*` tools; a global execution guard excludes normal shell, filesystem, messaging, model-switching, and delegation tools for attributed team agents. SDK visibility filters and per-request depth limits alone do not enforce that boundary. A fresh root is created for each stage and disposed afterwards. Durable run artifacts, not root residency, carry the lifecycle across stages/restarts.

Host-only API (invoke from authenticated trusted host integration, not an untrusted PR comment):

```ts
await ctx.teamConductor.preflight();
const run = await ctx.teamConductor.createTask('Implement the requested feature', 'main');
ctx.teamConductor.status();
ctx.teamConductor.audit(run.id, 100); // bounded host-only event history
ctx.teamConductor.budget(run.id); // durable reservations, not measured invoices
ctx.teamConductor.pause(run.id);
ctx.teamConductor.resume(run.id);
// Only after inspecting interrupted edits and remote state:
ctx.teamConductor.resume(run.id, true);
ctx.teamConductor.revisePlan(run.id, 'Approved scope change');
```

`enabled: false` does not start polling/model work and refuses `createTask`. Do not enable until all deployment checks below pass.

## Required deployment checks

1. Resolve each model through DSH and verify actual tool-call/structured-result behavior, context caps, cancellation, and latency. Validate vLLM tool parser/chat template and llama-swap alias/cold-load behavior.
2. Provision the forge credential through DSH's credential service. The execution token should be repository-scoped where possible and should **not** be an administrator or branch-protection bypass identity.
3. Confirm `reviewer-claude` and `reviewer-codex` are active, have access to the private repository, and their independent services subscribe to this repository. Knowing an account exists does not prove its reviewer process is running.
4. Protect the target branch: two approvals, required CI contexts, dismissed stale reviews, blocking rejected reviews, no internal-team merge/push bypass. Restrict merge authority to external identities. Ensure configured check names match the actual runner contexts.
5. Install rootless Podman (recommended) or an appropriately isolated Docker service. Preload the digest-pinned test image with dependencies: tests run with network disabled. Never expose a container socket or forge/model credentials to tests.
6. Verify the workspace cannot be edited by untrusted concurrent host processes. Team tools deny symlinks/hard links and `.git`, but filesystem path checks are not a kernel-level defense against a hostile co-resident host writer. Use a dedicated runtime/volume boundary for multi-tenant operation.
7. Run a disposable canary task, exercise external feedback, and verify external merge stops all work before enabling real tasks.

## Gitea authentication and repository bootstrap

For this deployment, HTTPS Git credentials are supplied by the scoped OpenBao helper. API calls need explicit authentication; the implementation resolves a configured DSH credential reference per request. Never put the PAT in URLs, prompts, logs, or committed files.

The private repository is published at **https://git.chifor.me/cchifor/dsh-team-conductor**. Gitea reports version `1.26.1`; authenticated account `dsh` successfully created the repository and pushed `main` after credential/quota provisioning was corrected. Both named reviewer accounts exist and have verified repository-scoped write access and admitted reviewer services. Gitea's redacted public `active:false` is not reviewer-health evidence; only explicit login prohibition is rejected at preflight. Codex has reviewed delivery PRs; Claude's recorded quota outage remains distinct from account eligibility. See `DEPLOYMENT-STATUS.md` for current evidence.

Bootstrap requires suitable token scopes (`write:user` for repository creation and `write:repository` for pushing/configuring it) **and** sufficient account-level permissions/quota. Scopes do not override an account's repository limit. Reduce bootstrap permissions afterward. Do not paste tokens into chat. Git helper authentication does not imply permission for every API operation.

### Repeatable bootstrap command

From a clean checkout on `main`, after the credential is provisioned:

```sh
npm run bootstrap:gitea                       # identity/reviewer checks; no mutations
npm run bootstrap:gitea -- --apply --push     # create/validate private repo, push, verify remote SHA
```

The script uses the scoped Git credential helper in memory, fixes the API authority to `https://git.chifor.me`, verifies API/Git identity agreement, checks both reviewer accounts, refuses public/mismatched repositories, refuses a dirty worktree or unexpected remote, and does not force-push. It does not grant reviewer access, modify branch protection, or prove reviewer services are running; finish those deployment checks before enabling automation.

## Webhooks and polling

Polling is the default correctness mechanism, with no model calls while idle. `createIngress(store, options)` is exported for mounting on an exact HTTP route behind TLS in the existing host or a dedicated ingress service. Options require source ID, fixed owner/repository and a secret resolver. It verifies `X-Gitea-Signature`, `X-Gitea-Delivery`, body limits and repository identity; duplicates are accepted without duplicate records. HTTP 202 is returned only after the durable inbox write.

Ingress does not trust event state as authoritative and does not inject raw text into model permissions. The next host reconciliation fetches canonical forge state. If no webhook route is mounted, polling still discovers reviews/merges. No public unauthenticated task-control endpoint is provided.

See [validation architecture](ops/validation/ARCHITECTURE.md) for the dev-worker/TEP comparison and [budget semantics](ops/validation/BUDGETS.md) for trusted usage versus conservative pre-dispatch reservations. Remote-helper implementation is under integration; [live evidence](ops/validation/LIVE-VALIDATION.md) records exactly which checks have passed.

## Recovery and bounded autonomy

- State transitions use revision checks and an exclusive renewable run lease.
- Stage intent is persisted before dispatch; completed structured results can be replayed without another model call.
- An interrupted stage with no durable result enters `NEEDS_ATTENTION`: inspect changes and explicitly resume. The engine does not blindly replay an agent that may already have edited files.
- Publication is reconcile-first. A crash after push can recover the matching local/remote approved tree; unexpected branch/base changes stop safely for operator reconciliation.
- PR creation binds to a deterministic branch and embedded run marker; it never silently adopts an unrelated PR.
- New commits invalidate current-head approvals; waiting for fresh reviewers does not itself request code changes.
- Stage/total attempt and wall-clock limits bound autonomy. The initial implementation does not include currency pricing or automatic model fallback.
- External closure becomes `CLOSED_UNMERGED`. Actual merge always stops writes and is recorded even when historical review-policy compliance needs audit.

## Deliberate limitations

Cancellation depends on DSH's cooperative subagent settlement. If a provider ignores abort, the global inference queue remains fenced instead of releasing a slot while a child may still be writing; an operator must terminate/restart that runtime. Verify abort settlement with the real model canary. Automatically releasing on a timer alone would allow overlapping unquiesced writers.

This is a conservative single-host implementation, not a distributed exactly-once scheduler. Multi-replica fencing, automatic rebase/conflict repair, automatic scope-change adjudication, monetary accounting, a custom GUI, and reviewer deployment management are not implemented. Operators handle scope changes with `revisePlan` and uncertain stages with inspection/resume. All external-feedback text is untrusted data. The initial planner/reviewer/worker contracts are intentionally compact; production evaluations should assess engineering quality before granting broad autonomy.

No claim of end-to-end live operation is made without a successful canary using the actual models, Gitea permissions, CI, and external reviewers.
