# Changelog

## 0.1.0 — release candidate

Initial restricted, single-coordinator release of the durable DSH conductor plugin. Release publication and deployment remain gated by `RELEASE-PLAN.md`; this file alone does not attest that they occurred.

### Included

- Native planning, internal plan review, implementation, isolated validation and internal candidate review.
- Host-owned Git publication, two independent current-head external reviews, feedback handling and external merge observation. No internal merge operation.
- SQLite durability, attempt/lease/inbox tracking, conservative model admission, recovery guards and bounded polling.
- Global execution-time role authorization, including descendant-owned tools; visibility filters and per-request depth limits are not security boundaries.
- Dedicated workspace file tools and digest-pinned no-network validator execution.
- Inert-by-default DSH profile bundle, private installable tarball and offline package/import tests.

### Supported routes

- Conductor: `openai-codex/gpt-6-astra`.
- Worker: `litellm/qwen3.8-27b-vllm-cloud`.
- Reviewer: `litellm/qwen3.8-flash-next-cloud`.

### Deployment limits

Node 24+, DSH 0.1.5-alpha.2, Cordis 4.0.2. Single coordinator with durable local SQLite locking; no hostile multi-tenancy claim. The verified validator uses runc inside a VM, not Kata. Operator SSH authority remains broad. Reservations/usage are not verified invoices. Uncertain work needs inspection, not blind replay. Cancellation is not atomic write rollback or proof of remote billing cancellation. Reviewer deployment and merge authority remain external. No custom GUI or automatic model fallback is included.
