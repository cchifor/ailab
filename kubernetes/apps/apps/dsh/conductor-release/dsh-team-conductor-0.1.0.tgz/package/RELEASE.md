# Private 0.1.0 release and deployment

Canonical source and release repository: **https://git.chifor.me/cchifor/dsh-team-conductor**. Keep `private: true`. Distribute a private Gitea **release asset**, not an npm registry publication. This procedure is not evidence that publication or rollout has already occurred; see `RELEASE-PLAN.md` and the release evidence.

## Gates

Require local and isolated tests, actual native tool-denial and supported-host package loading checks, two independent fresh external approvals, required CI and **external merge only**. Complete the approved fresh bounded native acceptance without resetting earlier state/budgets. Build from the exact reviewed source; record its SHA and all artifact hashes. If code changes after acceptance, repeat the affected gates.

## Build and verify

From a clean reviewed checkout on Node 24+:

```sh
npm ci --ignore-scripts
npm test
./ops/release/build-tarball.sh /absolute/fresh/output-directory
./ops/release/verify-install.sh /absolute/fresh/output-directory/dsh-team-conductor-0.1.0.tgz
./ops/release/verify-dsh-profile.sh /absolute/fresh/output-directory/dsh-team-conductor-0.1.0.tgz
```

The builder compiles and packs offline without lifecycle scripts; it refuses to overwrite an artifact. It produces a `.tgz` and `.tgz.sha256`. The install checker uses a disposable offline installation and a host Cordis peer (optional second argument, default checkout dependency), actually imports the installed service/profile, and checks the inert default. It is **not** the full DSH bundle-activation test. `verify-dsh-profile.sh` provides that separate gate using the real DSH executable (`DSH_BIN` override), pnpm, a disposable profile, actual SDK preset service and both inert/configured-disabled modes; it never starts Web or calls a model. A bare `dsh-base` profile lacks the required preset roster, whereas the intended Web bundle supplies it. A pnpm missing-peer warning before boot does not prove a failure: the supported host provides its shared Cordis module fallback, which the actual activation test verifies. Use a clean checkout to avoid stale generated build files. Never use a development dependency fixture as the DSH host.

The package includes runtime JS/types, `src/profile.mjs`, `cordis.patch.yml`, example configuration, README, release instructions and changelog. It excludes operational tests/scripts, credentials, databases and dependencies.

## Publish and verify private assets

Create the `v0.1.0` release only against the verified externally merged SHA. Preserve any existing tag/release; do not overwrite it silently. Upload the tarball, SHA256 file and release evidence through the authenticated Gitea release API. Asset uploads use the **numeric release ID** and multipart `attachment` field at `/api/v1/repos/cchifor/dsh-team-conductor/releases/{id}/assets`, not a tag-name endpoint or package-registry PUT.

Use the existing authorized credential mechanism, keep credentials in memory, pin the forge origin and reject credential-forwarding redirects. Do not paste PATs into shell examples, URLs or `.npmrc`. Download the published assets, verify their SHA256 against the local artifact, and test the downloaded package. Do not equate a successful upload with verified installation.

## Supported profile installation

Target: DSH **0.1.5-alpha.2**, Node **24+**, Cordis **4.0.2**. The exact Cordis peer pin is deliberate: this security-sensitive native boundary is verified against that host generation, not presumed compatible with an untested patch upgrade. Retarget and rerun native checks before widening it. The offline install checker uses `--legacy-peer-deps` to avoid registry resolution while supplying the exact host peer, not to claim compatibility with mismatched versions. DSH plugin management forwards to **pnpm**, which must be on PATH. The preparation toolchain pins pnpm 10.11.0.

```sh
dsh plugin --profile web add /absolute/persistent/path/dsh-team-conductor-0.1.0.tgz
```

The package declares `dsh.bundle.patch`, so the supported plugin command can add its profile layer. `/dsh-teams/` contains agent presets and is **not** this package's installation directory. Merely installing a plain dependency or copying JS there does not activate the service.

The inserted profile entry is disabled unless `DSH_TEAM_CONDUCTOR_CONFIG` names an absolute, trusted JSON configuration file. Alternatively, an operator-managed later Cordis layer can override `team-conductor-profile` with `disabled: false` and an absolute `config.configPath`. A direct mount without a config path remains inert. Do not let repository content or model output choose this path.

Start with configuration `enabled: false`. The example's **one-call / 1M reserved-token** limit is a deliberately restrictive placeholder, not enough for a normal workflow. Set explicit per-deployment/per-run limits before use. The separately authorized acceptance budget of 40 calls / 40M reservations is **not** standing production spending approval. Put SQLite and configuration on durable operator-owned storage **outside** the model workspace root; use a separate durable checkout root. Create owner-only parent directories. Do not use `/var/lib` example paths unless they really have persistent writable mounts. Use one coordinator only. Project existing credential references, not credential values into configuration. Verify current forge protections/reviewers, configured model routes and the pinned validator/helper policy before enabling.

## Controlled activation

Record and back up the current profile manifest/lock/configuration and exact package before changes, preserving unrelated settings. Ensure authoritative boot configuration will not undo the installation. In this deployment, `seed-settings` replaces the Web profile's `node_modules` from the staged `/app/profiles/.../web` closure and then reconciles the bundle list. A live-profile CLI install alone therefore does **not** survive pod recreation. Include the verified private artifact in the authoritative staged closure/plugin-install Job and verify the reconciled layer before rollout; also preserve the activation configuration in authoritative boot configuration rather than editing the boot-overwritten profile patch. Retain the prior staged closure for rollback. Verify required network access explicitly; never replace restricted networking with broad private-network access.

A host profile startup/reload is required for this deployment; do not assume client HMR reloads a host service. Preserve the existing Web service and URL; do not start a replacement server. After the planned restart, verify its readiness and the actually loaded plugin version, successful preflight, persistent state, and idle operation without new model calls. Only then enable real tasks. A disabled service refuses task creation; model/forge preflight alone does not prove a clean acceptance.

## Disable and rollback

1. Stop admission of new tasks. Pause active runs and **wait for actual stage/tool settlement**; seeing `PAUSED` alone is not proof of quiescence.
2. Inspect uncertain writes, publication and remote validation cleanup. Preserve the database (including WAL state), checkouts, reservations and evidence; never delete them to obtain a clean restart.
3. Set `enabled: false` in trusted configuration, or disable the profile entry, and perform a controlled host reload/restart after drain. No automatic acknowledgement or refund.
4. If removing the initial release, restore the recorded prior profile/package configuration while preserving unrelated concurrent changes and durable data. Do not downgrade to the known visibility-only authorization implementation and enable execution.
5. Recheck the same Web endpoint and disabled/no-new-work behavior. Restore a prior runtime only if its state compatibility and safety are established; otherwise remain disabled for reconciliation.

## Explicit initial-release limits

Single coordinator, no hostile multi-tenancy claim; runc-in-VM validator rather than Kata; broad operator SSH authority; same-VM image archive; unverified monetary price ceilings; no claim of remote billing cancellation or atomic write rollback. External reviewers and merge authority remain independent. These limits must accompany the release rather than being hidden behind passing tests.
