import {readSync,openSync,closeSync,fstatSync,constants} from 'node:fs';
import {isAbsolute} from 'node:path';

export const name='team-conductor-profile';
export const inject=['agents','subagents','tools','credentials','agentPresets'];

/** Host-owned configuration only; never load a path supplied by a model. */
export function loadConfig(configPath){
 if(typeof configPath!=='string'||!isAbsolute(configPath))throw Error('Absolute trusted configuration path required');
 let fd;
 try{
  fd=openSync(configPath,constants.O_RDONLY|constants.O_NONBLOCK);const stat=fstatSync(fd);
  if(!stat.isFile()||stat.size>1048576)throw Error('Invalid configuration file');
  // Bound the actual read too, including a file that grows after fstat.
  const bytes=Buffer.alloc(1048577);let length=0;
  while(length<bytes.length){const n=readSync(fd,bytes,length,bytes.length-length,null);if(!n)break;length+=n;}
  if(length>1048576)throw Error('Invalid configuration file');
  const text=bytes.subarray(0,length).toString('utf8');
  let config;try{config=JSON.parse(text);}catch{throw Error('Invalid configuration JSON');}
  if(!config||typeof config!=='object'||Array.isArray(config))throw Error('Configuration must be an object');
  return config;
 }catch{throw Error('Unable to load trusted conductor configuration');}
 finally{if(fd!==undefined)closeSync(fd);}
}

export async function apply(ctx,options={}){
 // Inert even when mounted directly without an explicit configuration path.
 if(options.configPath===undefined)return;
 const config=loadConfig(options.configPath);
 const {default:TeamConductor}=await import('../dist/plugin.js');
 ctx.plugin(TeamConductor,config);
}
export default {name,inject,apply};
